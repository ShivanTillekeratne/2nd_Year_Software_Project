// src/components/Footer.js

import React from 'react';

const Footer = () => {
  return (
    <div className="bg-slate-300 text-white p-4">
      {/* Footer content goes here */}
    </div>
  );
};

export default Footer;
